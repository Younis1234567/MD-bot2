# ꧁༒☬ MUHAMMAD YOUNIS MD ☬༒꧂

WhatsApp multi-device bot + website (QR / pairing code / logout / connected info).

## Chalane ka tareeqa
1. `npm install`
2. `npm start`
3. Website kholein (host ka URL, port 3000), QR scan ya pairing code se WhatsApp link karein.
4. WhatsApp mein `.menu` likhein.

Optional environment variables: `OWNER_NUMBER` (923001234567), `ADMIN_KEY` (website password), `PORT`,
`AI_API_KEY` / `AI_BASE_URL` / `AI_MODEL` (apna AI key, warna free AI chalta hai).

## Naya feature kaise add karein
`commands/<category>/<name>.js` mein nayi file banayein:

    module.exports = {
      name: 'hello', aliases: ['hi'], desc: 'Say hello', usage: '<name>',
      // ownerOnly: true, groupOnly: true, adminOnly: true, botAdmin: true,
      run: async (c) => c.reply('Hello ' + c.text),
    };

Bot restart karein, `.menu` mein khud aa jayega. Nayi category = nayā folder.

## Structure
- `config.js` naam, prefix, owner
- `lib/` core (bot, handler, loader, db)
- `commands/` har command ki alag file
- `web/` website
