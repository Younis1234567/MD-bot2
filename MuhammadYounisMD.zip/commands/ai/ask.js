const ai = require('../../lib/ai');
module.exports = { name: 'ask', aliases: ['ai', 'gpt', 'chatgpt'], desc: 'Ask AI anything', usage: '<question>', run: async (c) => {
  if (!c.text) return c.reply(`Usage: ${c.prefix}ask <sawal>`);
  await c.reply('🧠 ' + (await ai(c.text)));
} };
