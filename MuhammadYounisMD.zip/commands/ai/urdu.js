const ai = require('../../lib/ai');
module.exports = { name: 'urdu', desc: 'AI answer in Roman Urdu', usage: '<question>', run: async (c) => {
  if (!c.text) return c.reply(`Usage: ${c.prefix}urdu <sawal>`);
  await c.reply('🧠 ' + (await ai('Answer in simple Roman Urdu: ' + c.text)));
} };
