const U = require('../../lib/utils');
module.exports = { name: 'apk', desc: 'Download APK (Aptoide)', usage: '<app name>', run: async (c) => {
  if (!c.text) return c.reply(`Usage: ${c.prefix}apk <app name>`);
  const r = await U.get('https://ws75.aptoide.com/api/7/apps/search?limit=1&query=' + encodeURIComponent(c.text));
  const a = r.datalist && r.datalist.list && r.datalist.list[0];
  if (!a) throw new Error('App nahi mili');
  const mb = (a.file.filesize || 0) / 1048576;
  if (mb > 90) return c.reply(`❌ App bohat bari hai (${mb.toFixed(0)} MB).`);
  await c.reply(`📦 *${a.name}*\nVersion: ${a.file.vername}\nSize: ${mb.toFixed(1)} MB\n⏳ Bhej raha hoon...`);
  await c.send({ document: { url: a.file.path }, fileName: a.name + '.apk', mimetype: 'application/vnd.android.package-archive' });
} };
