const { fbdown } = require('btch-downloader'); const dl = require('../../lib/dl');
module.exports = { name: 'fb', aliases: ['facebook'], desc: 'Facebook downloader', usage: '<link>', run: async (c) => {
  if (!dl.need(c)) return;
  const r = await fbdown(c.args[0]);
  const u = r.HD || r.Normal_video || dl.urls(r).find((x) => !dl.isImg(x));
  if (!u) throw new Error('Video nahi mili');
  await dl.sendMedia(c, u, '✅ ' + c.config.botName);
} };
