const { igdl } = require('btch-downloader'); const dl = require('../../lib/dl');
module.exports = { name: 'ig', aliases: ['insta', 'instagram'], desc: 'Instagram downloader', usage: '<link>', run: async (c) => {
  if (!dl.need(c)) return;
  const r = await igdl(c.args[0]);
  const list = [...new Set((Array.isArray(r) ? r : [r]).map((x) => x.url || dl.urls(x)[0]).filter(Boolean))].slice(0, 5);
  if (!list.length) throw new Error('Media nahi mili');
  for (const u of list) await dl.sendMedia(c, u, '✅ ' + c.config.botName);
} };
