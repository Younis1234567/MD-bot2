const { mediafire } = require('btch-downloader'); const dl = require('../../lib/dl');
module.exports = { name: 'mediafire', desc: 'MediaFire downloader', usage: '<link>', run: async (c) => {
  if (!dl.need(c)) return;
  const r = await mediafire(c.args[0]);
  const u = r.link || r.url || dl.urls(r)[0];
  if (!u) throw new Error('File nahi mili');
  await c.send({ document: { url: u }, fileName: r.filename || 'file', mimetype: 'application/octet-stream' });
} };
