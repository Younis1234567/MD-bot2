const { pinterest } = require('btch-downloader'); const dl = require('../../lib/dl');
module.exports = { name: 'pin', aliases: ['pinterest'], desc: 'Pinterest downloader', usage: '<link>', run: async (c) => {
  if (!dl.need(c)) return;
  const r = await pinterest(c.args[0]);
  const all = dl.urls(r);
  const u = all.find((x) => !dl.isImg(x)) || all[0];
  if (!u) throw new Error('Media nahi mili');
  await dl.sendMedia(c, u, '✅ ' + c.config.botName);
} };
