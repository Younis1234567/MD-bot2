const U = require('../../lib/utils'); const dl = require('../../lib/dl');
module.exports = { name: 'tt', aliases: ['tiktok'], desc: 'TikTok downloader', usage: '<link>', run: async (c) => {
  if (!dl.need(c)) return;
  const r = await U.get('https://www.tikwm.com/api/?url=' + encodeURIComponent(c.args[0]));
  if (!r.data || !r.data.play) throw new Error('Video nahi mili');
  await c.send({ video: { url: r.data.play }, caption: '🎵 ' + (r.data.title || '') });
} };
