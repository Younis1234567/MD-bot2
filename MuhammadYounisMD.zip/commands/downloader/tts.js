const U = require('../../lib/utils'); const dl = require('../../lib/dl');
module.exports = { name: 'tts', desc: 'TikTok audio', usage: '<link>', run: async (c) => {
  if (!dl.need(c)) return;
  const r = await U.get('https://www.tikwm.com/api/?url=' + encodeURIComponent(c.args[0]));
  if (!r.data || !r.data.music) throw new Error('Audio nahi mili');
  await c.send({ audio: { url: r.data.music }, mimetype: 'audio/mpeg' });
} };
