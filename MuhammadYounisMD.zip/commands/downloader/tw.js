const { twitter } = require('btch-downloader'); const dl = require('../../lib/dl');
module.exports = { name: 'tw', aliases: ['x', 'twitter'], desc: 'Twitter/X downloader', usage: '<link>', run: async (c) => {
  if (!dl.need(c)) return;
  const r = await twitter(c.args[0]);
  const u = dl.urls(r).find((x) => !dl.isImg(x)) || dl.urls(r)[0];
  if (!u) throw new Error('Media nahi mili');
  await dl.sendMedia(c, u, '✅ ' + c.config.botName);
} };
