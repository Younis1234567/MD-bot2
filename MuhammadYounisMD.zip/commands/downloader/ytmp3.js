const { youtube } = require('btch-downloader'); const dl = require('../../lib/dl');
module.exports = { name: 'ytmp3', desc: 'YouTube to MP3', usage: '<link>', run: async (c) => {
  if (!dl.need(c)) return;
  const r = await youtube(c.args[0]);
  if (!r.mp3) throw new Error('Audio nahi mili');
  await c.send({ audio: { url: r.mp3 }, mimetype: 'audio/mpeg' });
} };
