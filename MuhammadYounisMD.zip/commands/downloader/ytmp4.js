const { youtube } = require('btch-downloader'); const dl = require('../../lib/dl');
module.exports = { name: 'ytmp4', desc: 'YouTube to MP4', usage: '<link>', run: async (c) => {
  if (!dl.need(c)) return;
  const r = await youtube(c.args[0]);
  if (!r.mp4) throw new Error('Video nahi mili');
  await c.send({ video: { url: r.mp4 }, caption: r.title || '' });
} };
