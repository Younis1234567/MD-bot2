const U = require('../../lib/utils');
module.exports = { name: 'fact', desc: 'Random fact', run: async (c) => {
  const f = await U.get('https://uselessfacts.jsph.pl/api/v2/facts/random?language=en');
  await c.reply('🧩 ' + f.text);
} };
