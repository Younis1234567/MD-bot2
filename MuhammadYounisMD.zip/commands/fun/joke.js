const U = require('../../lib/utils');
module.exports = { name: 'joke', desc: 'Random joke', run: async (c) => {
  const j = await U.get('https://official-joke-api.appspot.com/random_joke');
  await c.reply(`😂 ${j.setup}\n\n👉 ${j.punchline}`);
} };
