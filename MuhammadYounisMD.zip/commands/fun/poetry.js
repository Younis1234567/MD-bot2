const U = require('../../lib/utils');
module.exports = { name: 'poetry', desc: 'Random poem', run: async (c) => {
  const p = (await U.get('https://poetrydb.org/random/1'))[0];
  await c.reply(`📜 *${p.title}*\n_${p.author}_\n\n${p.lines.slice(0, 12).join('\n')}`);
} };
