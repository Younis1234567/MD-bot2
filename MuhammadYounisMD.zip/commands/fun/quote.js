const U = require('../../lib/utils');
module.exports = { name: 'quote', desc: 'Random quote', run: async (c) => {
  const q = (await U.get('https://zenquotes.io/api/random'))[0];
  await c.reply(`💬 “${q.q}”\n— ${q.a}`);
} };
