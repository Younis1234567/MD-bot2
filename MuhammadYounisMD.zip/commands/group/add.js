module.exports = { name: 'add', desc: 'Add member by number', usage: '<number>', groupOnly: true, adminOnly: true, botAdmin: true, run: async (c) => {
  const n = c.args.join('').replace(/\D/g, '');
  if (n.length < 8) return c.reply(`Usage: ${c.prefix}add 923001234567`);
  const r = await c.sock.groupParticipantsUpdate(c.jid, [n + '@s.whatsapp.net'], 'add');
  c.reply(r && r[0] && String(r[0].status) !== '200' ? '❌ Add nahi ho saka (privacy ya number galat).' : '✅ Add ho gaya');
} };
