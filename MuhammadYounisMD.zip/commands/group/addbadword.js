module.exports = { name: 'addbadword', desc: 'Add banned word', usage: '<word>', groupOnly: true, adminOnly: true, run: async (c) => {
  const w = c.text.toLowerCase();
  if (!w) return c.reply(`Usage: ${c.prefix}addbadword <word>`);
  const g = c.db.group(c.jid); g.badwords = g.badwords || [];
  if (!g.badwords.includes(w)) g.badwords.push(w);
  c.db.saveGroup(); c.reply('✅ Add ho gaya: ' + w);
} };
