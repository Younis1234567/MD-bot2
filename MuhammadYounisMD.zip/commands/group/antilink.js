module.exports = { name: 'antilink', desc: 'Block group links', usage: 'on/off/kick', groupOnly: true, adminOnly: true, botAdmin: true, run: async (c) => {
  const v = (c.args[0] || '').toLowerCase();
  const g = c.db.group(c.jid);
  if (!['on', 'off', 'kick'].includes(v)) return c.reply(`Antilink: *${(g.antilink || 'off').toUpperCase()}*\nUse: ${c.prefix}antilink on/off/kick\n(on = delete+warn, kick = delete+remove)`);
  g.antilink = v; c.db.saveGroup(); c.reply(`✅ Antilink: *${v.toUpperCase()}*`);
} };
