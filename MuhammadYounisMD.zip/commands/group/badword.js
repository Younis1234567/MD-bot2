module.exports = { name: 'badword', desc: 'Delete bad words', usage: 'on/off', groupOnly: true, adminOnly: true, botAdmin: true, run: async (c) => {
  const v = (c.args[0] || '').toLowerCase();
  const g = c.db.group(c.jid);
  if (!['on', 'off'].includes(v)) return c.reply(`Badword: *${g.badword ? 'ON' : 'OFF'}*\nUse: ${c.prefix}badword on/off`);
  g.badword = v === 'on'; c.db.saveGroup(); c.reply(`✅ Badword: *${v.toUpperCase()}*`);
} };
