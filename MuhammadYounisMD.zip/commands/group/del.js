module.exports = { name: 'del', aliases: ['delete'], desc: 'Delete replied message', groupOnly: true, adminOnly: true, botAdmin: true, run: async (c) => {
  const q = c.quotedInfo;
  if (!q.stanzaId) return c.reply('Jis message ko delete karna hai us par reply karein.');
  await c.sock.sendMessage(c.jid, { delete: { remoteJid: c.jid, fromMe: false, id: q.stanzaId, participant: q.participant } });
} };
