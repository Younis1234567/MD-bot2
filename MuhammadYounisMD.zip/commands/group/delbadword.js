module.exports = { name: 'delbadword', desc: 'Remove banned word', usage: '<word>', groupOnly: true, adminOnly: true, run: async (c) => {
  const g = c.db.group(c.jid); const w = c.text.toLowerCase();
  g.badwords = (g.badwords || []).filter((x) => x !== w); c.db.saveGroup(); c.reply('✅ Remove ho gaya.');
} };
