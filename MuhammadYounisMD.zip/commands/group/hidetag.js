module.exports = { name: 'hidetag', desc: 'Silent mention everyone', usage: '<message>', groupOnly: true, adminOnly: true, run: async (c) => {
  await c.send({ text: c.text || '📢', mentions: c.meta.participants.map((p) => p.id) });
} };
