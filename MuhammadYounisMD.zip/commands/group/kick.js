module.exports = { name: 'kick', desc: 'Remove member', usage: '@user', groupOnly: true, adminOnly: true, botAdmin: true, run: async (c) => {
  const t = [...new Set([...(c.mentions || []), ...(c.quotedInfo.participant ? [c.quotedInfo.participant] : [])])];
  if (!t.length) return c.reply('Kisi ko @mention karein ya uske message par reply karein.');
  await c.sock.groupParticipantsUpdate(c.jid, t, 'remove');
  c.reply('✅ Remove kar diya');
} };
