module.exports = { name: 'tagall', desc: 'Mention everyone', usage: '[message]', groupOnly: true, adminOnly: true, run: async (c) => {
  const ids = c.meta.participants.map((p) => p.id);
  await c.send({ text: `📢 *${c.text || 'Attention!'}*\n\n` + ids.map((i) => '@' + i.split('@')[0]).join('\n'), mentions: ids });
} };
