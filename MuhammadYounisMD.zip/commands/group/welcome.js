module.exports = { name: 'welcome', desc: 'Welcome new members', usage: 'on/off', groupOnly: true, adminOnly: true, run: async (c) => {
  const v = (c.args[0] || '').toLowerCase();
  const g = c.db.group(c.jid);
  if (!['on', 'off'].includes(v)) return c.reply(`Welcome: *${g.welcome ? 'ON' : 'OFF'}*\nUse: ${c.prefix}welcome on/off`);
  g.welcome = v === 'on'; c.db.saveGroup(); c.reply(`✅ Welcome: *${v.toUpperCase()}*`);
} };
