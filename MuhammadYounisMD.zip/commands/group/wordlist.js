module.exports = { name: 'wordlist', desc: 'Show banned words', groupOnly: true, adminOnly: true, run: async (c) => {
  const g = c.db.group(c.jid);
  c.reply((g.badwords || []).length ? '🚫 ' + g.badwords.join(', ') : 'Koi word add nahi.');
} };
