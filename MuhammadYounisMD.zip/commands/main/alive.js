const U = require('../../lib/utils');
module.exports = { name: 'alive', desc: 'Bot status', run: async (c) =>
  c.reply(`✅ *${c.config.botName}* is alive\n⏳ Uptime: ${U.uptime(Date.now() - c.state.startedAt)}\n💬 Messages: ${c.state.msgs}\n⌨️ Commands used: ${c.state.cmds}`) };
