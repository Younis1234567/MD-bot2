const { list } = require('../../lib/loader');
const U = require('../../lib/utils');
const ICON = { main: '🏠 MAIN', downloader: '📥 DOWNLOADER', youtube: '🎬 YOUTUBE', tools: '✨ SMART TOOLS', ai: '🧠 AI CHAT', group: '🛡️ GROUP CONTROL', owner: '👑 OWNER SETTINGS', fun: '🎭 FUN' };
module.exports = {
  name: 'menu', aliases: ['help', 'cmds'], desc: 'Show all commands',
  run: async (c) => {
    const cats = {};
    for (const cmd of list) (cats[cmd.category] = cats[cmd.category] || []).push(cmd);
    const order = Object.keys(ICON).filter((k) => cats[k]).concat(Object.keys(cats).filter((k) => !ICON[k]));
    let t = `╭━━━━━━━━━━━━━━━━━━╮\n  ⚡ *${c.config.botName}* ⚡\n  _Premium WhatsApp Bot_\n╰━━━━━━━━━━━━━━━━━━╯\n\n`;
    t += `┌「 🤖 *BOT INFO* 」\n│ 👑 Owner → ${c.config.ownerName}\n│ 🔌 Mode → ${c.db.setting('mode', c.config.mode).toUpperCase()}\n│ 🔰 Prefix → [ ${c.prefix} ]\n│ 📊 Cmds → ${list.length}\n│ ⏳ Uptime → ${U.uptime(Date.now() - c.state.startedAt)}\n└──────────────\n`;
    for (const k of order) {
      t += `\n┌「 ${ICON[k] || '📂 ' + k.toUpperCase()} 」\n`;
      t += cats[k].map((x) => `│ ▸ ${c.prefix}${x.name}${x.usage ? ' ' + x.usage : ''}`).join('\n');
      t += `\n└──────────────\n`;
    }
    t += `\n━━━━━━━━━━━━━━━━━━\n*POWERED BY ${c.config.ownerName}*\n_${c.config.credit}_`;
    await c.reply(t);
  },
};
