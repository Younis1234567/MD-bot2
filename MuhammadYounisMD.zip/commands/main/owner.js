module.exports = { name: 'owner', desc: 'Owner info', run: async (c) =>
  c.reply(`👑 *Owner:* ${c.config.ownerName}\n🛠️ ${c.config.credit}`) };
