module.exports = { name: 'ping', desc: 'Bot speed', run: async (c) => {
  const t = Date.now(); await c.reply('🏓 Pong!'); await c.reply(`⚡ ${Date.now() - t} ms`);
} };
