module.exports = require('../../lib/toggle')('alwaysonline', 'Always online', 'Always show online');
