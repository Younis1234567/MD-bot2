module.exports = require('../../lib/toggle')('anticall', 'Anti-call', 'Auto reject calls');
