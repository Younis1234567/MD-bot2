module.exports = require('../../lib/toggle')('antidelete', 'Anti-delete', 'Deleted msgs sent to your inbox');
