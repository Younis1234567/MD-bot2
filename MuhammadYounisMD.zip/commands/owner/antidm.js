module.exports = require('../../lib/toggle')('antidm', 'Anti-DM', 'Ignore commands in private chats');
