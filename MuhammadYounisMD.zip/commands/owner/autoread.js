module.exports = require('../../lib/toggle')('autoread', 'Auto read', 'Auto read messages');
