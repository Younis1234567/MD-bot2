module.exports = require('../../lib/toggle')('autostatus', 'Auto status view', 'Auto view statuses');
