module.exports = { name: 'mode', desc: 'public / private', usage: 'public/private', ownerOnly: true, run: async (c) => {
  const v = (c.args[0] || '').toLowerCase();
  if (!['public', 'private'].includes(v)) return c.reply(`Mode: *${c.db.setting('mode', c.config.mode)}*\nUse: ${c.prefix}mode public/private`);
  c.db.setSetting('mode', v); c.reply(`✅ Mode: *${v.toUpperCase()}*`);
} };
