module.exports = { name: 'setprefix', desc: 'Change prefix', usage: '<symbol>', ownerOnly: true, run: async (c) => {
  const p = c.args[0];
  if (!p || p.length > 3) return c.reply(`Usage: ${c.prefix}setprefix .`);
  c.db.setSetting('prefix', p); c.reply(`✅ Prefix ab: [ ${p} ]`);
} };
