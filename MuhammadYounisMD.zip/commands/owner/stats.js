const U = require('../../lib/utils');
module.exports = { name: 'stats', desc: 'Bot statistics', ownerOnly: true, run: async (c) =>
  c.reply(`📊 *Stats*\n⏳ Uptime: ${U.uptime(Date.now() - c.state.startedAt)}\n💬 Messages: ${c.state.msgs}\n⌨️ Commands: ${c.state.cmds}\n🧠 RAM: ${(process.memoryUsage().rss / 1048576).toFixed(0)} MB`) };
