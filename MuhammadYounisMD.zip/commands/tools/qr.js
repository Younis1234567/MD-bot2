module.exports = { name: 'qr', desc: 'Make QR code', usage: '<text>', run: async (c) => {
  if (!c.text) return c.reply(`Usage: ${c.prefix}qr <text/link>`);
  await c.send({ image: { url: 'https://api.qrserver.com/v1/create-qr-code/?size=500x500&data=' + encodeURIComponent(c.text) }, caption: '✅ QR ready' });
} };
