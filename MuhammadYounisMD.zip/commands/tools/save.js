const U = require('../../lib/utils');
module.exports = { name: 'save', desc: 'Save replied media/status to your inbox', ownerOnly: true, run: async (c) => {
  const media = U.mediaOf(c.quoted);
  if (!media) return c.reply('Kisi media (status/photo/video) par reply karke likhein.');
  const buf = await U.download(media.node, media.type);
  const me = U.num(c.sock.user.id) + '@s.whatsapp.net';
  const key = { image: 'image', video: 'video', audio: 'audio', sticker: 'sticker', document: 'document' }[media.type];
  await c.sock.sendMessage(me, { [key]: buf, ...(key === 'document' ? { mimetype: media.node.mimetype, fileName: media.node.fileName || 'file' } : {}), ...(key === 'audio' ? { mimetype: media.node.mimetype } : {}) });
} };
