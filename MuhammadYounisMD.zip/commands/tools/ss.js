module.exports = { name: 'ss', aliases: ['screenshot'], desc: 'Website screenshot', usage: '<url>', run: async (c) => {
  if (!c.args[0]) return c.reply(`Usage: ${c.prefix}ss <url>`);
  const u = /^https?:\/\//.test(c.args[0]) ? c.args[0] : 'https://' + c.args[0];
  await c.send({ image: { url: 'https://image.thum.io/get/width/1280/' + u }, caption: u });
} };
