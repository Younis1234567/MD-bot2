const { Sticker } = require('wa-sticker-formatter'); const U = require('../../lib/utils');
module.exports = { name: 'sticker', aliases: ['s'], desc: 'Image/video to sticker', run: async (c) => {
  const media = U.mediaOf(c.msg) || U.mediaOf(c.quoted);
  if (!media || !['image', 'video'].includes(media.type)) return c.reply('Image/video ke saath ya us par reply karke likhein.');
  const buf = await U.download(media.node, media.type);
  const s = await new Sticker(buf, { pack: c.config.botName, author: c.config.ownerName, type: 'full', quality: 60 }).toBuffer();
  await c.send({ sticker: s });
} };
