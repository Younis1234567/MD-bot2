const U = require('../../lib/utils');
module.exports = { name: 'tr', aliases: ['translate'], desc: 'Translate', usage: '<lang> <text>', run: async (c) => {
  const lang = c.args[0]; let t = c.args.slice(1).join(' ');
  if (!t && c.quoted) t = require('../../lib/utils').getText(c.quoted);
  if (!lang || !t) return c.reply(`Usage: ${c.prefix}tr ur Hello world\n(ya kisi message ko reply karke ${c.prefix}tr ur)`);
  const r = await U.get(`https://api.mymemory.translated.net/get?q=${encodeURIComponent(t)}&langpair=autodetect|${lang}`);
  await c.reply('🌐 ' + r.responseData.translatedText);
} };
