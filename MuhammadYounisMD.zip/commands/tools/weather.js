const U = require('../../lib/utils');
module.exports = { name: 'weather', desc: 'Weather of a city', usage: '<city>', run: async (c) => {
  if (!c.text) return c.reply(`Usage: ${c.prefix}weather <city>`);
  const r = await U.get('https://wttr.in/' + encodeURIComponent(c.text) + '?format=j1');
  const w = r.current_condition[0];
  await c.reply(`🌤️ *${c.text}*\n🌡️ ${w.temp_C}°C (feels ${w.FeelsLikeC}°C)\n☁️ ${w.weatherDesc[0].value}\n💧 Humidity: ${w.humidity}%\n💨 Wind: ${w.windspeedKmph} km/h`);
} };
