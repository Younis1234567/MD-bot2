const U = require('../../lib/utils');
module.exports = { name: 'wiki', aliases: ['google'], desc: 'Quick search (Wikipedia)', usage: '<topic>', run: async (c) => {
  if (!c.text) return c.reply(`Usage: ${c.prefix}wiki <topic>`);
  const r = await U.get('https://en.wikipedia.org/api/rest_v1/page/summary/' + encodeURIComponent(c.text.replace(/ /g, '_')));
  await c.reply(`📖 *${r.title}*\n\n${r.extract}\n\n🔗 ${r.content_urls && r.content_urls.desktop.page}`);
} };
