const ys = require('yt-search'); const { youtube } = require('btch-downloader');
module.exports = { name: 'play', aliases: ['song'], desc: 'Search & send song', usage: '<name>', run: async (c) => {
  if (!c.text) return c.reply(`Usage: ${c.prefix}play <song name>`);
  const v = (await ys(c.text)).videos[0];
  if (!v) throw new Error('Kuch nahi mila');
  await c.send({ image: { url: v.thumbnail }, caption: `🎵 *${v.title}*\n⏱️ ${v.timestamp}  👁️ ${v.views}\n⏳ Audio bhej raha hoon...` });
  const r = await youtube(v.url);
  if (!r.mp3) throw new Error('Audio download nahi hui');
  await c.send({ audio: { url: r.mp3 }, mimetype: 'audio/mpeg', fileName: v.title + '.mp3' });
} };
