const ys = require('yt-search'); const { youtube } = require('btch-downloader');
module.exports = { name: 'video', desc: 'Search & send video', usage: '<name>', run: async (c) => {
  if (!c.text) return c.reply(`Usage: ${c.prefix}video <name>`);
  const v = (await ys(c.text)).videos[0];
  if (!v) throw new Error('Kuch nahi mila');
  const r = await youtube(v.url);
  if (!r.mp4) throw new Error('Video download nahi hui');
  await c.send({ video: { url: r.mp4 }, caption: '🎬 ' + v.title });
} };
