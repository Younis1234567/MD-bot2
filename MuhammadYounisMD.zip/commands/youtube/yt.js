const ys = require('yt-search');
module.exports = { name: 'yt', desc: 'YouTube video info', usage: '<name/link>', run: async (c) => {
  if (!c.text) return c.reply(`Usage: ${c.prefix}yt <name>`);
  const v = (await ys(c.text)).videos[0];
  if (!v) throw new Error('Kuch nahi mila');
  await c.send({ image: { url: v.thumbnail }, caption: `🎬 *${v.title}*\n👤 ${v.author.name}\n⏱️ ${v.timestamp}\n👁️ ${v.views}\n🔗 ${v.url}\n\nAudio: ${c.prefix}ytmp3 ${v.url}\nVideo: ${c.prefix}ytmp4 ${v.url}` });
} };
