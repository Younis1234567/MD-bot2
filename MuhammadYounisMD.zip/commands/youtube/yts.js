const ys = require('yt-search');
module.exports = { name: 'yts', desc: 'YouTube search', usage: '<name>', run: async (c) => {
  if (!c.text) return c.reply(`Usage: ${c.prefix}yts <name>`);
  const v = (await ys(c.text)).videos.slice(0, 6);
  await c.reply(v.map((x, i) => `${i + 1}. *${x.title}*\n   ⏱️ ${x.timestamp} | ${x.url}`).join('\n\n') || 'Kuch nahi mila');
} };
