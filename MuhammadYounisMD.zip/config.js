module.exports = {
  prefix: '.',
  botName: '꧁༒☬ MUHAMMAD YOUNIS MD ☬༒꧂',
  ownerName: '꧁༒☬ MUHAMMAD YOUNIS ☬༒꧂',
  credit: 'Muhammad Yunus, Developer',
  // Owner number with country code, digits only (e.g. 923001234567). Linked number is always owner too.
  ownerNumber: (process.env.OWNER_NUMBER || '').replace(/\D/g, ''),
  mode: 'public', // default mode: public | private (.mode se badal sakte hain)
  port: process.env.PORT || 3000,
  sessionDir: 'session',
  // Website ka password (pair/logout ke liye). Khali chhodein to koi password nahi.
  adminKey: process.env.ADMIN_KEY || '',
};
