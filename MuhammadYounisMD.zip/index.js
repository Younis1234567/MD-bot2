const bot = require('./lib/bot');
require('./web/server')(bot);
bot.start().catch((e) => console.error('Start error:', e));
process.on('unhandledRejection', (e) => console.error('Unhandled:', e && e.message ? e.message : e));
process.on('uncaughtException', (e) => console.error('Uncaught:', e && e.message ? e.message : e));
