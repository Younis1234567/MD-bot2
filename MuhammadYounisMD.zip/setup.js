// Pehli baar chalane par: git check/install -> packages install -> bot start.
const { spawnSync } = require('child_process');
const fs = require('fs');
const path = require('path');
process.chdir(__dirname);

const DEPS = [
  '@whiskeysockets/baileys@6.7.9', 'axios@1', 'btch-downloader', 'express@4',
  'pino@9', 'qrcode@1', 'wa-sticker-formatter@4', 'yt-search@2',
];
const has = (c) => spawnSync(c, ['--version'], { stdio: 'ignore' }).status === 0;
const run = (cmd) =>
  spawnSync(cmd, { shell: true, stdio: 'inherit', env: { ...process.env, DEBIAN_FRONTEND: 'noninteractive' } }).status === 0;

function ensureGit() {
  if (has('git')) return true;
  console.log('⚙️ git nahi mila, install karne ki koshish kar raha hoon...');
  const tries = [
    'apt-get update -y && apt-get install -y git',
    'apk add --no-cache git',
    'dnf install -y git',
    'yum install -y git',
    'sudo apt-get install -y git',
  ];
  for (const t of tries) if (run(t) && has('git')) { console.log('✅ git install ho gaya'); return true; }
  return false;
}

if (!fs.existsSync(path.join('node_modules', '@whiskeysockets', 'baileys'))) {
  if (!ensureGit()) {
    console.error('❌ git install nahi ho saka (root/apt permission nahi). Host par git chahiye.');
    process.exit(1);
  }
  console.log('📦 Packages install ho rahe hain...');
  if (!run('npm install --no-save --no-audit --no-fund ' + DEPS.join(' '))) {
    console.error('❌ npm install fail ho gaya, upar ka error dekhein.');
    process.exit(1);
  }
}
require('./index.js');
