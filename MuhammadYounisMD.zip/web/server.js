const path = require('path');
const express = require('express');
const QRCode = require('qrcode');
const config = require('../config');

module.exports = (bot) => {
  const app = express();
  app.use(express.json());
  app.use(express.static(path.join(__dirname, 'public')));

  const auth = (req, res, next) => {
    if (config.adminKey && req.headers['x-admin-key'] !== config.adminKey)
      return res.status(401).json({ error: 'Admin key galat hai' });
    next();
  };

  app.get('/api/status', async (req, res) => {
    const s = bot.getState();
    res.json({
      status: s.status,
      user: s.user,
      uptime: Date.now() - s.startedAt,
      qr: s.qr ? await QRCode.toDataURL(s.qr, { margin: 1, width: 300 }) : null,
      botName: config.botName,
      owner: config.ownerName,
      credit: config.credit,
      needKey: !!config.adminKey,
    });
  });

  app.post('/api/pair', auth, async (req, res) => {
    try { res.json({ code: await bot.requestPairing(req.body.number) }); }
    catch (e) { res.status(400).json({ error: e.message }); }
  });

  app.post('/api/logout', auth, async (req, res) => {
    await bot.logout();
    res.json({ ok: true });
  });

  app.listen(config.port, '0.0.0.0', () => console.log('🌐 Website on port ' + config.port));
};
